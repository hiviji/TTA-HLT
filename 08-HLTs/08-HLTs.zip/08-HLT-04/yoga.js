document.getElementById("ash").innerHTML ="<span class=day>Tuesday</span><span class=hour> 4PM</span>";
document.getElementById("yin").innerHTML ="<span class=day>Thursday</span><span class=hour> 8PM</span>";
document.getElementById("hat").innerHTML ="<span class=day>Saturday</span><span class=hour> 6PM</span>";