for(n=0; n<= 15; n++){
remainder = n % 2;
if(remainder ==1){
    console.log(n+" is odd");
}
else{
    console.log(n+" is even");
}
}